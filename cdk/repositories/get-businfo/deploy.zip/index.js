const request = require('request');
const convert = require('xml-js');

exports.handler = async (event) => {
    console.log('## ENVIRONMENT VARIABLES: ' + JSON.stringify(process.env));
    console.log('## EVENT: ' + JSON.stringify(event));

    var statusCode;
    var isCompleted = false;
    try {
        const options = { 
            uri: 'http://openapi.gbis.go.kr/ws/rest/busarrivalservice', 
            method: 'GET',
            qs:{ 
                serviceKey: '1234567890', // default
                stationId: '122000202',
                routeId: '222000074',
                staOrder: '81'
            },
        };
    
        var statusCode;
        request(options, function (error, response, body) { 
            statusCode = response.statusCode;
            if(!error && statusCode==200) {
                console.log('error: '+error);
                console.log('response: '+JSON.stringify(response));
    
                statusCode = response.statusCode;
                console.log('statusCode: '+statusCode);
    
                console.log('xml body: '+body);
                var json = convert.xml2json(body, {compact: true, spaces: 4});
                console.log('json: '+json);



            }
            else {
                console.log('error: '+error);                
            }

            isCompleted = true;
        });
    } catch(err) {
        console.log(err);
    };

    function wait(){
        return new Promise((resolve, reject) => {
          if(!isCompleted) {
            setTimeout(() => resolve("wait..."), 1000)
          }
          else {
            setTimeout(() => resolve("wait..."), 0)
          }
        });
      }
      console.log(await wait());
      console.log(await wait());
      console.log(await wait());
      console.log(await wait());
      console.log(await wait());
    
    const response = {
        statusCode: 200,
      //  result: JSON.stringify(result)
    };

    return response
}
